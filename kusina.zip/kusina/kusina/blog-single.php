<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Kusina - Free Bootstrap 4 Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lovers+Quarrel" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light ftco-navbar-light-2" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.html">Kusina</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	        	<li class="nav-item"><a href="index.html" class="nav-link">Home</a></li>
            <li class="nav-item"><a href="about.html" class="nav-link">About</a></li>
            <li class="nav-item active"><a href="connect.html" class="nav-link">connect</a></li>

	        	<li class="nav-item"><a href="menu.php" class="nav-link">Specialties</a></li>
            <li class="nav-item"><a href="reservation.php" class="nav-link">vehicles</a></li>
            <li class="nav-item"><a href="blog-single.php" class="nav-link">stories</a></li>
	          <li class="nav-item"><a href="contact.html" class="nav-link">Contact</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    <?php
        include 'class projet php/classes/employe.class.php' ;
        $employe = new employe ;
        if (!empty($_POST)) {
            $employe->updateemploye($_POST['id'], $_POST['nom'], $_POST['tel'], $_POST['mail'], $_POST['motdepasse']);
            header('Location:index.php?notif=update');
            exit();}
         else {
            $showemploye= $employe->showOneemploye($_GET['eid']);
            $data = $showemploye->fetch();
        }
    ?>
    <div class="container py-3">
      <div class="jumbotron text-center">
          <h3>Editer l'employe</h3>
      </div>
      <fieldset>
          <legend>Mettre à jour l'employe N°<?= $_GET['eid'] ?></legend>
          <form action="" method="post">
              <input type="hidden" value="<?= $data['eid'] ?>" name="eid">
              <div class="row">
                  <div class="col-md-6">
                      <div class="form-group">
                          <label for="nom">nom</label>
                          <input type="text" value="<?= $data['nom'] ?>" required name="nom" class="form-control" id="nom">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label for="tel">tel</label>
                          <input type="text" value="<?= $data['tel'] ?>" required name="tel" class="form-control" id="tel">
                      </div>
                  </div>
              </div>
              <div class="row">
                  <div class="col-md-6">
                      <div class="form-group">
                          <label for="email">email</label>
                          <input type="text" value="<?= $data['email'] ?>" required name="email" class="form-control" id="email">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label for="motdepasse">motdepasse</label>
                          <input type="text" value="<?= $data['motdepasse'] ?>" required name="motdepasse" class="form-control" id="motdepasse">
                      </div>
                  </div>
              </div>
              <div class="row">
                  <div class="col-md-6">
                      <button type="submit" class="btn btn-block btn-outline-primary">Enregistrer</button>
                  </div>
                  <div class="col-md-6">
                      <button type="reset" class="btn btn-block btn-outline-secondary">Annuler</button>
                  </div>
              </div>
      
  </div>
    
            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>