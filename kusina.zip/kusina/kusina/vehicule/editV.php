<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="jumbotron">
            <h1>Modifier Véhicule N°<?= $_GET['id'] ?></h1>
        </div>
        <?php
        include 'vehicule/classes/vehicule.class.php';
        $vehicule = new Vehicule;
        if (!empty($_POST)) {
            $upveh=$vehicule->updateVehicule($_POST['id'],$_POST['status'],$_POST['num_vehicule']);
            header('Location:listevehicules.php?notif=update');
            exit();
        } else {
            $showvehicule = $vehicule->showOneVehicule($_GET['id']);
            $data=$showvehicule->fetch();
        }
    ?>
        <form class="form-horizontal" method="POST" action="">
            <div class="form-group">
                <input type="hidden" class="form-control" value="<?= $data['id'] ?>" name="id">
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2" for="status">Statut</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" value="<?= $data['status_veh']?>" name="status">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2" for="num_vehicule">Numero de Vehicule</label>
                <div class="col-sm-10">
                    <input type="number" class="form-control" value="<?= $data['num_veh']?>" name="num_vehicule">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">enregistrer</button>
            <button class="btn  btn-secondary">Annuler</button>
        </form>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>