<?php
require 'vehicule/classes/dbconnect.class.php';
class Vehicule{
    private $connexion;
    public function __construct()
    {
        $db=new BasesDonnees;
        $this->connexion=$db->connect();
    }
    public function readAllVehicule(){
        try {
             $rep="SELECT * FROM vehicles";
             $result=$this->connexion->prepare($rep);
             $result->execute();
             return $result;
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }
    public function showOneVehicule($id)
    {
        try {
            $req = "SELECT * FROM vehicles WHERE id= :param_id";
            $result = $this->connexion->prepare($req);
            $result->bindParam(":param_id",$id);
            $result->execute();
            return $result;
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    public function createVehicule($status_veh,$num_veh){
        try {
             $rep='INSERT INTO vehicles(status_veh,num_veh) VALUES (:param_status,:param_numvehicule)';
             $result=$this->connexion->prepare($rep);
             $result->bindParam(':param_status',$status_veh);
             $result->bindParam(':param_numvehicule',$num_veh); 
             $result->execute();
             return $result;
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }
    public function updateVehicule($id,$status_veh,$num_veh){
        try {
            $rep='UPDATE vehicles
            SET status_veh= :param_status,
            num_veh= :param_numvehicule
             where id= :param_id';
            $result=$this->connexion->prepare($rep);
            $result->bindParam(":param_id",$id); 
            $result->bindParam(":param_status",$status_veh); 
            $result->bindParam(":param_numvehicule",$num_veh);
            $result->execute();
             return $result;
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }
    public function deleteVehicule($id){
        try {
            $rep='DELETE FROM vehicles WHERE id= :param_id';
            $result=$this->connexion->prepare($rep);
            $result->bindParam(':param_id',$id); 
            $result->execute();
             return $result;
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }
}