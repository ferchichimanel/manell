<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
<?php
    if (!empty($_POST)) {
        include 'vehicule/classes/vehicule.class.php';
        $vehicule = new vehicule;
        $vehicule->createVehicule($_POST['status'],$_POST['num_vehicule']);
        header('Location:listevehicules.php?notif=add');
        exit();
    }
    ?>
<div class="container">
    <div class="jumbotron">
        <h1>Nouvel Véhicule</h1>
    </div>
    
    <form class="form-horizontal" method="POST" action="">
        <div class="form-group">
            <label class="control-label col-sm-2" for="status">Statut</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" placeholder="Enter le statut" name="status">
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-sm-2" for="num_vehicule">Numero de Vehicule</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="num_vehicule">
            </div>
        </div>
      <button type="submit" class="btn btn-primary">Enregistrer</button>
      <button type="submit" class="btn btn-secondary">Annuler</button>
    </form>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>