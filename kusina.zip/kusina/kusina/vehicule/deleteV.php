<?php 
require 'vehicule/classes/vehicule.class.php';
$deltvehicule=new Vehicule;
$deltvehicule->deleteVehicule($_GET['id']);
header('Location:listevehicules.php?notif=delete');
?>

