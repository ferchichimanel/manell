<?php
    include 'Produit/classes/produit.class.php';
    $produit = new Produit;
    $produit->deleteproduit($_GET['id']);
    header('Location:Produitindex.php');
?>