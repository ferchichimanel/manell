<?php
    require 'Produit/classes/dbconnect.class.php';
    class Produit
    {
        private $cnx;
        public function __construct()
        {
            $db = new BasesDonnees;
            $this->cnx = $db->connectDB();
        }
        public function readAllproduit()
        {
            try {
                $req = 'SELECT * FROM products';
                $result = $this->cnx->prepare($req);
                $result->execute();
                return $result;
            } catch (PDOException $e) {
                echo $e->getMessage();
            }
        }
        public function showOneproduit($id)
        {
            try {
                $req = 'SELECT * FROM products WHERE id= :pro_id';
                $result = $this->cnx->prepare($req);
                $result->bindParam(':pro_id', $id);
                $result->execute();
                return $result;
            } catch (PDOException $e) {
                echo $e->getMessage();
            }
        }
        public function addNewproduit($nom,$description,$prix,$fichier)
        {
            try {
            $sql = "INSERT INTO products(nom,description,prix,fichier) VALUES (:pro_nom,:pro_description,:pro_prix,:pro_fichier)";
            $result = $this->cnx->prepare($sql);
            $result->bindparam(":pro_nom",$nom);
            $result->bindparam(":pro_description",$description);
            $result->bindparam(":pro_prix",$prix);
            $result->bindparam(":pro_fichier",$fichier);
            $result->execute();
            return $result;
            } catch (PDOException $ex) {
                echo $ex->getMessage();
            }
        }
        public function updateproduit($id,$nom,$description,$prix,$fichier)
        {
            try {
                $sql = 'UPDATE products
                        SET nom = :pro_nom,
                            description=:pro_description,
                            prix = :pro_prix,
                            fichier = :pro_fichier
                        WHERE id = :pro_id';
                $result = $this->cnx->prepare($sql);
                $result->bindparam(":pro_id",$id);
                $result->bindparam(":pro_nom",$nom);
                $result->bindparam(":pro_description",$description);
                $result->bindparam(":pro_prix",$prix);
                $result->bindparam(":pro_fichier",$fichier);
                $result->execute();
                return $result;
            } catch (PDOException $exception) {
                echo $exception->getMessage();
            }
        }
        public function deleteproduit($id)
        {
            try {
                $sql = 'DELETE FROM products WHERE id = :pro_id';
                $result = $this->cnx->prepare($sql);
                $result->bindparam(":pro_id", $id);
                $result->execute();
                return $result;
            } catch (PDOException $exception) {
                echo $exception->getMessage();
            }
        }
    }