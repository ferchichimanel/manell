<?php
require 'commande.class.php';
$nom_client=$_POST['nomc'];
$nom_produit=$_POST['nomp'];
$quantite_pro=$_POST['quantite_pro'];
$odate=$_POST['date'];
$commande= new Commande();
$commande->createCommande($nom_client,$nom_produit,$quantite_pro,$odate);
header("location:mgrcommandes.php");
?>