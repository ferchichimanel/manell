<?php
require 'commande.class.php';
$id=$_GET['id'];
$delecomm=new Commande();
$delecomm->deleteCommande($id);
header('location:mgrcommandes.php');
?>
