<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <title>Gestion commande</title>
</head>
<body>
<div class="container">
    <div class="jumbotron">
    <h1>Liste des commandes</h1>
    </div>
    <a href="createCommande.php" class="btn btn-primary" role="button" class=""><i class="fas fa-user-plus">Nouvelle commande</i></a>
    <br>
    <table class="table table-hover">
    <tr>
    <th>Id</th>
    <th>Nom de client</th>
    <th>Nom de produit</th>
    <th>Quantité de produit</th>
    <th>Date de commande</th>
    <th>Opérations</th>
    </tr>
    <?php
    require 'commande.class.php';
    $commande=new Commande;
    $listcommande=$commande->readAllCommandes();
    while($data=$listcommande->fetch())
    {
        echo'<tr>';
        echo'<td>'.$data['id'].'</td>';
        echo'<td>'.$data['nom_client'].'</td>';
        echo'<td>'.$data['nom_produit'].'</td>';
        echo'<td>'.$data['quantite_pro'].'</td>';
        echo'<td>'.$data['odate'].'</td>';
        echo'<td><a href="modificationCommande.php?id='.$data['id'].'"><i class="fas fa-user-edit">Editer</i></a>&nbsp;&nbsp';
        echo'<a href="deleteCommande.php?id='.$data['id'].'"><i class="fas fa-user-times">Supprimer</i></a></td>';
        echo'</tr>';
    }
    ?>
    </table>
    </div>
    
    <!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>