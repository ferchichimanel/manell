<?php
class Database{
    private $dbname = 'projet';
    private $dbuser = 'root';
    private $dbpwd = '';
    private $dbhost = 'localhost';
    public $conex;

    public function connectDB(){
        $this->conex = null;
        try{
            $this->conex = new PDO('mysql:host='.$this->dbhost.';dbname='.$this->dbname,$this->dbuser,$this->dbpwd);
        }
        catch (PDOException $e){
            echo "Erreur de connexion: ".$e->getMessage();
        }
        return $this->conex;
    }
}
?>
