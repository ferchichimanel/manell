<?php
require 'dbconnect.class.php';
class Commande{
    private $conex ;
    public function __construct(){
        $db=new Database;
        $connect=$db->connectDB();
        $this->conex=$connect;
    }
    private function execReq($sql){
        $stmt=$this->conex->prepare($sql);
        return $stmt;
    }
    public function createCommande($nom_client,$nom_produit,$quantite_pro,$odate){
        try {
            $sql="INSERT INTO orders(nom_client,nom_produit,quantite_pro,odate) VALUES (:com_nc,:com_np,:com_qp,:com_date)";
            $result=$this->execReq($sql);
            $result->bindparam(":com_nc",$nom_client);
            $result->bindparam(":com_np",$nom_produit);
            $result->bindparam(":com_qp",$quantite_pro);
            $result->bindparam(":com_date",$odate);
            $result->execute();
            return $result;
        } catch (PDOException $e){
            echo "Erreur de connexion: ".$e->getMessage();
        }
    }
    public function readAllCommandes(){
        try {
            $sql='SELECT * FROM orders';
            $result=$this->execReq($sql);
            $result->execute();
            return $result;
        } catch (PDOException $e){
            echo "Erreur de connexion: ".$e->getMessage();
        }
    }
    public function readidcommandes($id){
        try {
            $sql='SELECT * FROM orders WHERE id=:com_id';
            $req=$this->execReq($sql);
            $req->bindparam(":com_id",$id);
            $req->execute();
            return $req;
        } catch (PDOException $e){
            echo "Erreur de connexion: ".$e->getMessage();
        }
    }
    public function updateCommande($id,$nom_client,$nom_produit,$quantite_pro,$odate){
        try {
            $sql='UPDATE orders SET nom_client=:com_nc, nom_produit=:com_np, quantite_pro=:com_qp, odate=:com_date WHERE id=:com_id';
            $result=$this->execReq($sql);
            $result->bindparam(":com_id",$id);
            $result->bindparam(":com_nc",$nom_client);
            $result->bindparam(":com_np",$nom_produit);
            $result->bindparam(":com_qp",$quantite_pro);
            $result->bindparam(":com_date",$odate);
            $result->execute();
            return $result;
        } catch (PDOException $e){
            echo "Erreur de connexion: ".$e->getMessage();
        }
    }
    public function deleteCommande($id){
        try {
            $sql='DELETE FROM orders WHERE id=:com_id';
            $result=$this->execReq($sql);
            $result->bindparam(":com_id",$id);
            $result->execute();
            return $result;
        } catch (PDOException $e){
            echo "Erreur de connexion: ".$e->getMessage();
        }
    }
}
?>