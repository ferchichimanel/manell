<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <title>createCommande</title>
</head>
<body>
<div class="container">
<fieldset>
<legend>Nouvelle commande</legend>
<form action="storeCommande.php" class="form-horizontal" method="POST">
<div class="form-group">
<label for="Nom de client" class="control-label">Nom de client :</label>
<div class="col-sm-7">
<input type="text" name="nomc" id="nc" placeholder="entrer non de client">
</div>
</div>
<div class="form-group">
<label for="Nom de produit" class="control-label">Nom de produit :</label>
<div class="col-sm-7">
<input type="text" name="nomp" id="np" placeholder="entrer nom de produit">
</div>
</div>
<div class="form-group">
<label for="Quantité de produit" class="control-label">Quantité de produit :</label>
<div class="col-sm-7">
<input type="number" name="quantite_pro" id="qp" placeholder="entrer quantité de produit">
</div>
</div>
<div class="form-group">
<label for="La date de commande" class="control-label">La date de commande :</label>
<div class="col-sm-7">
<input type="date" name="date" id="d" placeholder="entrer date de commande">
</div>
</div>
<div class="form-group">
<div class="col-sm-offset">
<button type="submit" class="btn btn-success">Créer commande</button>
</div>
</div>
</form>
</fieldset>
</div>
    <!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script> 
</body>
</html>